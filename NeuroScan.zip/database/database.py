import os

DB_NAME = "my_database.sqlite"
DB_PATH = os.path.normpath(os.path.join("C:/", "NeuroScan", DB_NAME)).replace("\\","/")



