def login_query(username, password):

    pass
def register_query():
    pass
def recover_password():
    pass